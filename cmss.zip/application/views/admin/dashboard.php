<h1>Selamat Datang Di Halaman, Dashboard</h1>
<?= $this->session->userdata('nama'); ?>